var usernameField = document.getElementById('username');
let emailField = document.getElementById('email');
let dobField = document.getElementById('dob');
let form = document.getElementById('Registration');
var playerBounty = 100;//initializes the players bounty to 100
var aiBounty = 100;//initializes the ai bounty to 100
var aiHand = 0;//initializes the players bounty to 100
var guessField = document.getElementById('playerGuess');
var numGames = 0;//tracks number of 
var numGuess = 3;//tracks the number of guesses available
var gamesWon = 0;//tracks games won by the player
var gamesLost = 0;//tracks games lost by the player
var numFemales = 0;//tracks the number of female players
var numMales=0;//tracks the number of male players
var ageGroup1=0;//tracks the number fo players <20
var ageGroup2=0;//tracks the number of players 20 to 39
var ageGroup3=0;//tracks the number of players 40 to 69
var ageGroup4=0;//tracks the number of players >69
var numPlayers=0;//tracks the total num of players
let currentAge=0;//stores the player's age
var playerData = [];//array that will hold the players info
var percentScore=0;//initializes the percentage score to zero
var dataset = "";//stores all players
var currentPlayer = "";//stores current player playing
document.getElementById('registerButton').onclick = Register;
document.getElementById('quitButton').onclick = findPercentageScore;
document.getElementById('resultsButton').onclick = findPercentageScore;
document.getElementById('quitButton').onclick = quitGame;
document.getElementById('guessButton').onclick = checkGuess;
document.getElementById('playButton').onclick = PlayGame;

document.getElementById('playagainButton').onclick = PlayGame;

//refreshes the charts every 5 seconds
var intervalId = window.setInterval(function(){
  showfreq();
}, 5000);

usernameField.onkeyup = checkUsername;//checks the username input on each key
emailField.onkeyup = checkEmail;//checks the email input on each key
dobField.onchange = checkDob;//checks the date of birth on each change
guessField.onkeyup = guessIsValid;//checks if the players guess is valid

//username validation function
function checkUsername() {
  let usernameValue = document.getElementById('username').value;

  if (usernameValue.length < 3) {
    document.getElementById('usernameError').textContent = "Username must be atleast 3 characters long";
    document.getElementById('usernameError').style.display = "block";
    return false;
  } else {
    document.getElementById('usernameError').style.display = "none";
    return true;
  }
}

//email validation function
function checkEmail() {

  // regex for email validation
  let emailFormat = /^[a-zA-Z0-9._%+-]+@gmail.com/i
  let email = emailField.value.trim();//strips empty spaces from the email entered

  if (email.match(emailFormat)) {
    document.getElementById('emailError').style.display = "none";
    return true;
  } else {
    document.getElementById('emailError').innerHTML = "Invalid Email! Must be \"@gmail.com\" with \"_\" the only special character allowed.";
    document.getElementById('emailError').style.display = "inline-block";
    return false;
  }
}

//function that checks if a valid dob is entered and calculates the age
function checkDob() {

  var currentDate = new Date();
  currentDate.setHours(0, 0, 0, 0);

  let playerDob = new Date(dobField.value);

  var dateDiff = currentDate.getTime()-playerDob.getTime();
  var calc = Math.round(dateDiff / (1000 * 60 * 60 * 24));
  var days = Math.ceil(calc);   
  currentAge = Math.ceil(days/365);
    
  document.getElementById('age').value = currentAge;
    if(dobField.value == ""){
        document.getElementById('dobError').innerHTML = "Invalid DOB: DOB cannot be blank!";
        document.getElementById('dobError').style.display = "inline-block";
        return false
    }else{
  if (currentAge<6){
    document.getElementById('dobError').innerHTML = "Invalid DOB: User Must Be Older Than 5 Years Of Age!";
    document.getElementById('dobError').style.display = "inline-block";
    
      return false
  } else {
    document.getElementById('dobError').innerHTML = "";
    document.getElementById('dobError').style.display = "none";
      return true
      }
    }
}

//function to check the player gender
function checkGender() {

  let selectedGender = document.querySelectorAll('input[name = "gender"]:checked');
 
  //checks if a gender is selected and throws an error if none is submitted
  if (selectedGender.length == 0) {
    document.getElementById('genderError').innerHTML = "Please select a gender!"
    document.getElementById('genderError').style.display = "inline-block";
    return false
  } else {
    document.getElementById('genderError').style.display = "none";
    return true
  }
}

//disables the first 7 input elements
function toggleFormInputState(state) {
  for (let j = 0; j <= 6; j++) {
    form[j].disabled = state;
  }
}

//register function
function Register() {
  if (checkUsername() && checkDob() && checkEmail() && checkGender()) {

    //increments the number of players that have played 
    numPlayers+=1;

    //initializes number of games played, won and lost to 0 
    numGames=0;
    gamesLost=0;
    gamesWon=0;
    //initializes player bounty and aibounty to 0
    playerBounty=100;
    aiBounty=100;

    //used to update the player dataset with each new player
    dataset+=currentPlayer;
    currentPlayer="";
    //push the player info to the player data array
    playerData.push(usernameField.value, dobField.value, emailField.value, document.getElementById('age').value, document.querySelectorAll('input[name = "gender"]:checked')[0].value);

      //checks the players age and increments the appropriate agegroup
       if(currentAge<20){
                ageGroup1+=1;
        }else if(currentAge>=20 && currentAge <= 39){
                ageGroup2+=1;
        }else if(currentAge>=40 && currentAge <= 69){
                ageGroup3+=1;
        }else if(currentAge>69){
                ageGroup4+=1;
        }

        //checks the players gender and increments the appropriate agegroup
        if(document.querySelectorAll('input[name = "gender"]:checked')[0].value == "Male"){
            numMales+=1;
        }else if(document.querySelectorAll('input[name = "gender"]:checked')[0].value == "Female"){
            numFemales+=1;
        }
    toggleFormInputState("true");//disables the input elements of the form
    document.getElementById('playButton').removeAttribute('disabled');
    // document.getElementById('quitButton').removeAttribute('disabled');


  } else {
   
    //function calls to display where the error is 
    checkUsername()
    checkDob()
    checkEmail()
    checkGender()

  }
}//end of Register()


//function to check if the player's guess is valid
function guessIsValid() {
  let guessAmount = guessField.value;
   (guessAmount);
  let re = /[0-9]/;
  if (guessAmount.match(re)) {
    if (guessAmount > playerBounty) {
      //prevents the guess from being submitted and displays error message
      document.getElementById('guessError').innerHTML = "Guess Invalid, Greater Than Player Bounty!";
      document.getElementById('guessError').style.display = "inline-block";

      return false
    } else {
      document.getElementById('guessError').style.display = "none";
        
      return true
    }
  } else {
    document.getElementById('guessError').innerHTML = "Guess Invalid, Guess must be a number!";
    document.getElementById('guessError').style.display = "inline-block";

    return false
  }
}

//function to check if the guess is correct
function checkGuess() {
  let guessAmount = guessField.value;

  if (guessIsValid() && numGuess > 0) {
    if (guessAmount == aiHand) {
        var gameResult ="W";
      numGames += 1;
      gamesWon += 1;//increments the amount of games won 
      playerBounty = Number(playerBounty) + Number(guessAmount);
      aiBounty = Number(aiBounty) - Number(aiHand);
      document.getElementById('aiBounty').innerHTML = "AI Bounty " + aiBounty;
      document.getElementById('playerBounty').innerHTML = "Player Bounty " + playerBounty;
      document.getElementById('guessError').innerHTML = "Correct! " + guessAmount + " kernels has been added to your Bounty";
      document.getElementById('guessError').style.display = "inline-block";
        document.getElementById("guessButton").disabled=true;
        document.getElementById("playagainButton").disabled=false;

    } else if (guessAmount > aiHand) {
        numGuess--
      document.getElementById('guessError').innerHTML = "Too High! Try Again " + numGuess + " Guesses Remaining";
      document.getElementById('guessError').style.display = "inline-block";
      // guessField.value = "";
      // guessField.placeholder = playerGuess;
    } else if (guessAmount < aiHand) {
        numGuess--
      document.getElementById('guessError').innerHTML = "Too Low! Try Again " + numGuess + " Guesses Remaining";
      document.getElementById('guessError').style.display = "inline-block";
    }
    findPercentageScore();
  }

  if (numGuess == 0) {
    var gameResult="L";
    numGuess=3;//sets player guesses to 3
    numGames += 1;
    gamesLost += 1;//increments the amount of games lost
    playerBounty = Number(playerBounty) - Number(aiHand);
    aiBounty = Number(aiBounty) + Number(aiHand);

    document.getElementById('aiBounty').innerHTML = "AI Bounty " + aiBounty;
    document.getElementById('playerBounty').innerHTML = "Player Bounty " + playerBounty;
    document.getElementById('guessError').innerHTML = "Ooph!!! " + aiHand + " kernels has been taken from your Bounty";
    document.getElementById('guessError').style.display = "inline-block";
    document.getElementById("guessButton").disabled=true;
    document.getElementById("playagainButton").disabled=false;
      
  }
    
    if(playerBounty<1){

        document.getElementById('guessError').innerHTML = "Ooph!!! " + aiHand + " kernels has been taken from your Bounty! Game Over!";
    document.getElementById('guessError').style.display = "inline-block";
        document.getElementById("guessButton").disabled=true;
        document.getElementById("playagainButton").disabled=true;
        document.getElementById("playButton").disabled=true;
        document.getElementById("registerButton").disabled=false;
        playerBounty=100;
        aiBounty=100;
    }
    playerData.push(numGames, playerBounty, gameResult);
    showAll();
}

//game function
function PlayGame() {

   numGuess = 3;// reinitializes the number of guesses to 3 each time a new game is started
   findPercentageScore();

  if (aiBounty >= 100) {
    aiHand = Math.floor(Math.random() * 100) + 1;
  } else {
    aiHand = Math.floor(Math.random() * aiBounty) + 1;
  }

  document.getElementById("playerGuess").reset;
  document.getElementById("guessError").style.display= "none";  
  document.getElementById('guessButton').removeAttribute('disabled');
  document.getElementById('playButton').disabled=true;
  document.getElementById('playagainButton').disabled=true;
  document.getElementById('quitButton').removeAttribute('disabled');
    document.getElementById('playerGuess').removeAttribute('disabled');

  document.getElementById('aiBounty').innerHTML = "AI Bounty " + aiBounty;
  document.getElementById('playerBounty').innerHTML = "Player Bounty " + playerBounty;
  document.getElementById('gameMessage').innerHTML = "SHIP SAIL,SHIP SAIL, ‘OW MUCH MAN DEH PON BOARD!";
  document.getElementById('gameMessage').style.display = "inline-block";

    // showAll();
} 
  //function collect the user stats and prints them to the text area
function findPercentageScore() {
    percentScore = (Number(gamesWon) / Number(numGames)) * 100;
    
    if(numGames==0){
        percentScore = 0;
    }
    let today = new Date();
    today = today.getDate()+ "/" + (today.getMonth()+1) + "/" + today.getFullYear();
    document.getElementById('showpercentage').reset;//clears the area
    document.getElementById('showpercentage').innerHTML = "Username: "+ document.getElementById("username").value +"," +"Total Games: " + numGames +"," + "Games Won: " + gamesWon+"," + "Games Lost: " + gamesLost+"," + "Percentage Score: " + percentScore + "%" + ","+ "Date: " + today;
    currentPlayer = "Username: "+ document.getElementById("username").value +"," +"Total Games: " + numGames +"," + "Games Won: " + gamesWon+"," + "Games Lost: " + gamesLost+"," + "Percentage Score: " + percentScore + "%\n";
}

//function to quit the game
function quitGame() {
    form.reset();
    
    document.getElementById('username').removeAttribute("disabled");
    document.getElementById('dob').removeAttribute("disabled");
    document.getElementsByName('gender')[0].removeAttribute("disabled");
    document.getElementsByName('gender')[1].removeAttribute("disabled");
    document.getElementById('email').removeAttribute("disabled");
    document.getElementById('registerButton').removeAttribute("disabled");
    document.getElementById('resultsButton').removeAttribute("disabled");
} 

/** function for displaying all players**/
function showAll(){
        document.getElementById('showallplayers').innerHTML = "";//clears the area

    document.getElementById('showallplayers').innerHTML = dataset + currentPlayer;//prints current and previous players to the textarea


}

//function to push data to the charts 
function showfreq(){
    let percentMale = Math.round((numMales/numPlayers)*100);
    let percentFemale = Math.round((numFemales/numPlayers)*100);
    let percentageGroup1 = Math.round((ageGroup1/numPlayers)*100);
    let percentageGroup2 = Math.round((ageGroup2/numPlayers)*100);
    let percentageGroup3 = Math.round((ageGroup3/numPlayers)*100);
    let percentageGroup4 = Math.round((ageGroup4/numPlayers)*100);

    if(isNaN(percentMale)){
        document.getElementById("maleImg").style.width= "0%";
        document.getElementById("mPercent").innerHTML= "0%";
    }else{
        document.getElementById("maleImg").style.width = percentMale +"%";
        document.getElementById("mPercent").innerHTML= percentMale+"%";
    }
    
    if(isNaN(percentFemale)){
         ("bg");
        document.getElementById("femaleImg").style.width= "0%";
        document.getElementById("fPercent").innerHTML= "0%";
    }else{
         (percentFemale);
        document.getElementById("femaleImg").style.width= percentFemale+"%";
        document.getElementById("fPercent").innerHTML= percentFemale+"%";
    }
    if(isNaN(percentageGroup1) || numPlayers==0){
        document.getElementById("ageGroup1").style.width= "0%";
        document.getElementById("ageGroup1Percent").innerHTML= "0%";
    }else{
        document.getElementById("ageGroup1").style.width= percentageGroup1+"%";
        document.getElementById("ageGroup1Percent").innerHTML= percentageGroup1+"%";
    }
    if(isNaN(percentageGroup2) || numPlayers==0 ){
        document.getElementById("ageGroup2").style.width= "0%";
        document.getElementById("ageGroup2Percent").innerHTML= "0%";
    }else{
        document.getElementById("ageGroup2").style.width= percentageGroup2+"%";
        document.getElementById("ageGroup2Percent").innerHTML= percentageGroup2+"%";
    }
    if(isNaN(percentageGroup3) || numPlayers==0){
        document.getElementById("ageGroup3").style.width= "0%";
        document.getElementById("ageGroup3Percent").innerHTML= "0%";
    }else{
        document.getElementById("ageGroup3").style.width= percentageGroup3+"%";
        document.getElementById("ageGroup3Percent").innerHTML= percentageGroup3+"%";
    }
    if(isNaN(percentageGroup4) || numPlayers==0){
        document.getElementById("ageGroup4").style.width= "0%";
        document.getElementById("ageGroup4Percent").innerHTML= "0%";
    }else{
        document.getElementById("ageGroup4").style.width= percentageGroup4+"%";
        document.getElementById("ageGroup4Percent").innerHTML= percentageGroup4+"%";
    }
}